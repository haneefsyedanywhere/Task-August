export default [
    {
        date : "2018/10/02 10:57:46",
        detail : "Deposit Japanese Yen",
        activities : "+10,000 JPY"
    },
    {
        date : "2018/10/02 10:57:46",
        detail : "Bought Bitcoin",
        activities : "+ 0.00018147 BTC"
    },
    {
        date : "2018/10/02 10:57:46",
        detail : "Service fee",
        activities : "- 500 JPY"
    },
    {
        date : "2018/10/02 10:57:46",
        detail : "Deposit Japanese Yen",
        activities : "+10,000 JPY"
    },
    {
        date : "2018/10/02 10:57:46",
        detail : "Bought Bitcoin",
        activities : "+ 0.00018147 BTC"
    },
    {
        date : "2018/10/02 10:57:46",
        detail : "Service fee",
        activities : "- 500 JPY"
    }
]