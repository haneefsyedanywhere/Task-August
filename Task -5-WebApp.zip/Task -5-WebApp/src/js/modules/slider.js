const container=document.querySelector(".thumbnail-container");
const allBox=container.children;
const margin=30;
 var items=4;
 var totalItems=0;
 var jumpSlideWidth=0;

export default function(containerWidth){

    var totalItemsWidth=0;
    for(let i=0;i<allBox.length;i++){
       // width and margin setup of items
      allBox[i].style.width=(containerWidth/items)-margin + "px";
      allBox[i].style.margin=(margin/2)+ "px";
         totalItemsWidth+=containerWidth/items;
         totalItems++;
    }
    // thumbnail-container width set up
    container.style.width=totalItemsWidth + "px";
    return totalItemsWidth;
}

const prevButton = document.querySelector('.prevButton');

export let controlSlidesUsingArrow = function(ele,totalItemsWidth,containerWidth){
    if(ele==="next" ){
     jumpSlideWidth=jumpSlideWidth+containerWidth;
     prevButton.classList.remove('disabled');
   }
   else if(ele==="prev" && (jumpSlideWidth>0)){
     jumpSlideWidth=jumpSlideWidth-containerWidth;
   }
   if(ele==="next" && (jumpSlideWidth>=(totalItemsWidth))){
    console.log(jumpSlideWidth,totalItemsWidth,containerWidth);
    jumpSlideWidth = 0;
  }
  if(jumpSlideWidth < containerWidth){
    prevButton.classList.add('disabled');
  }

   container.style.marginLeft=-jumpSlideWidth + "px";
  }

