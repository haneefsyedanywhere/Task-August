import generateCandleStickChart from './candleStickChart';
import generateAreaSplineChart from './areaSpline';
let timerId;
let timerId_throttleFunc;
export let toggleArrow = function(container,containerName){
    container.addEventListener('click',()=>{
      document.querySelector(`#${containerName} .nav__downArrow`).classList.toggle('hide');
      document.querySelector(`#${containerName} .nav__rightArrow`).classList.toggle('hide');
    });
  }

export let addListener = function(container,containerName){
    container.addEventListener('click',()=>{
      document.querySelector(`#${containerName} .nav__items`).classList.toggle('hide');
    });
    toggleArrow(container,containerName);
  }
export let chartGenerator = function(){
  generateCandleStickChart();
  generateAreaSplineChart();
}
export let debounceFunction = function(func,delay){
  clearTimeout(timerId);

  timerId = setTimeout(func,delay);
}

export let throttleFunction = function(func,delay){
  if(timerId_throttleFunc){
    return;
  }

  timerId_throttleFunc = setTimeout(function(){
    func()
    timerId_throttleFunc = undefined;
  },delay);

}
