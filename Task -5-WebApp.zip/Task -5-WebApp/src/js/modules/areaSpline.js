export default function(){

    Highcharts.chart('BTC_chart', {
        chart: {
            type: 'areaspline',
            spacingTop: 0,
            spacingRight: 0,
            spacingBottom: 0,
            spacingLeft: 0,
            plotBorderWidth: 0
        },
        title: {
            text: null,
            enabled : false
        },
        tooltip: {
            shared: true,
            valueSuffix: ' units'
        },
        credits: {
            enabled: false
        },
        xAxis: {
          categories: [''],
          lineWidth : 0,
          title :{
            text : null
          },
          labels: {
            enabled: false
          }
        },
        yAxis: {
          title :{
            text : null
          },
          visible: false,
          labels: {
            enabled: false
          }
        },
        plotOptions: {
            areaspline: {
                fillOpacity: 0.2
            }
        },
        series: [{
            marker: {
               enabled: false
            },
            lineColor:'#ffc246',
            showInLegend: false, 
            data: [2,1 ,4, 3, 5, 4, 10, 6,8,12,5],
            color: {
                    linearGradient : {
                        x1: 1,
                        y1: 0,
                        x2: 0,
                        y2: 0
                    },
                    stops : [
                        [0, Highcharts.Color('#ffc246').setOpacity(1).get('rgba')],
                        [1, Highcharts.Color('#FFF').setOpacity(1).get('rgba')],
                    ]
                },
                fillColor : {
                    linearGradient : {
                        x1: 1,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops : [
                        [0, Highcharts.Color('#ffc246').setOpacity(0.7).get('rgba')],
                        [1, Highcharts.Color('#FFF').setOpacity(0).get('rgba')],
                    ]
                }
        }]
    });
    Highcharts.chart('ETH_chart', {
        chart: {
            type: 'areaspline',
            spacingTop: 0,
            spacingRight: 0,
            spacingBottom: 0,
            spacingLeft: 0,
            plotBorderWidth: 0
        },
        title: {
            text: null,
            enabled : false
        },
        tooltip: {
            shared: true,
            valueSuffix: ' units'
        },
        credits: {
            enabled: false
        },
        xAxis: {
        categories: [''],
        lineWidth : 0,
        title :{
            text : null
        },
        labels: {
            enabled: false
        }
        },
        yAxis: {
        title :{
            text : null
        },
        visible: false,
        labels: {
            enabled: false
        }
        },
        plotOptions: {
            areaspline: {
                fillOpacity: 0.2
            }
        },
        series: [{
            marker: {
            enabled: false
            },
            lineColor:'#5470de',
            showInLegend: false, 
            data: [2,1 ,4, 3, 5, 4, 10, 6,8,12,5],
            color: {
                    linearGradient : {
                        x1: 1,
                        y1: 0,
                        x2: 0,
                        y2: 0
                    },
                    stops : [
                        [0, Highcharts.Color('#5470de').setOpacity(1).get('rgba')],
                        [1, Highcharts.Color('#FFF').setOpacity(1).get('rgba')],
                    ]
                },
                fillColor : {
                    linearGradient : {
                        x1: 1,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops : [
                        [0, Highcharts.Color('#5470de').setOpacity(0.7).get('rgba')],
                        [1, Highcharts.Color('#FFF').setOpacity(0).get('rgba')],
                    ]
                }
        }]
    });
    Highcharts.chart('XEM_chart', {
        chart: {
            type: 'areaspline',
            spacingTop: 0,
            spacingRight: 0,
            spacingBottom: 0,
            spacingLeft: 0,
            plotBorderWidth: 0
        },
        title: {
            text: null,
            enabled : false
        },
        tooltip: {
            shared: true,
            valueSuffix: ' units'
        },
        credits: {
            enabled: false
        },
        xAxis: {
        categories: [''],
        lineWidth : 0,
        title :{
            text : null
        },
        labels: {
            enabled: false
        }
        },
        yAxis: {
        title :{
            text : null
        },
        visible: false,
        labels: {
            enabled: false
        }
        },
        plotOptions: {
            areaspline: {
                fillOpacity: 0.2
            }
        },
        series: [{
            marker: {
            enabled: false
            },
            lineColor:'#07beaa',
            showInLegend: false, 
            data: [2,1 ,4, 3, 5, 4, 10, 6,8,12,5],
            color: {
                    linearGradient : {
                        x1: 1,
                        y1: 0,
                        x2: 0,
                        y2: 0
                    },
                    stops : [
                        [0, Highcharts.Color('#07beaa').setOpacity(1).get('rgba')],
                        [1, Highcharts.Color('#FFF').setOpacity(1).get('rgba')],
                    ]
                },
                fillColor : {
                    linearGradient : {
                        x1: 1,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops : [
                        [0, Highcharts.Color('#07beaa').setOpacity(0.7).get('rgba')],
                        [1, Highcharts.Color('#FFF').setOpacity(0).get('rgba')],
                    ]
                }
        }]
    });
    Highcharts.chart('XRP_chart', {
        chart: {
            type: 'areaspline',
            spacingTop: 0,
            spacingRight: 0,
            spacingBottom: 0,
            spacingLeft: 0,
            plotBorderWidth: 0
        },
        title: {
            text: null,
            enabled : false
        },
        tooltip: {
            shared: true,
            valueSuffix: ' units'
        },
        credits: {
            enabled: false
        },
        xAxis: {
        categories: [''],
        lineWidth : 0,
        title :{
            text : null
        },
        labels: {
            enabled: false
        }
        },
        yAxis: {
        title :{
            text : null
        },
        visible: false,
        labels: {
            enabled: false
        }
        },
        plotOptions: {
            areaspline: {
                fillOpacity: 0.2
            }
        },
        series: [{
            marker: {
            enabled: false
            },
            lineColor:'#1786c4',
            showInLegend: false, 
            data: [2,1 ,4, 3, 5, 4, 10, 6,8,12,5],
            color: {
                    linearGradient : {
                        x1: 1,
                        y1: 0,
                        x2: 0,
                        y2: 0
                    },
                    stops : [
                        [0, Highcharts.Color('#1786c4').setOpacity(1).get('rgba')],
                        [1, Highcharts.Color('#FFF').setOpacity(1).get('rgba')],
                    ]
                },
                fillColor : {
                    linearGradient : {
                        x1: 1,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops : [
                        [0, Highcharts.Color('#1786c4').setOpacity(0.7).get('rgba')],
                        [1, Highcharts.Color('#FFF').setOpacity(0).get('rgba')],
                    ]
                }
        }]
    });
    

    Highcharts.chart('SlideFive_chart', {
        chart: {
            type: 'areaspline',
            spacingTop: 0,
            spacingRight: 0,
            spacingBottom: 0,
            spacingLeft: 0,
            plotBorderWidth: 0
        },
        title: {
            text: null,
            enabled : false
        },
        tooltip: {
            shared: true,
            valueSuffix: ' units'
        },
        credits: {
            enabled: false
        },
        xAxis: {
          categories: [''],
          lineWidth : 0,
          title :{
            text : null
          },
          labels: {
            enabled: false
          }
        },
        yAxis: {
          title :{
            text : null
          },
          visible: false,
          labels: {
            enabled: false
          }
        },
        plotOptions: {
            areaspline: {
                fillOpacity: 0.2
            }
        },
        series: [{
            marker: {
               enabled: false
            },
            lineColor:'#ffc246',
            showInLegend: false, 
            data: [2,1 ,4, 3, 5, 4, 10, 6,8,12,5],
            color: {
                    linearGradient : {
                        x1: 1,
                        y1: 0,
                        x2: 0,
                        y2: 0
                    },
                    stops : [
                        [0, Highcharts.Color('#ffc246').setOpacity(1).get('rgba')],
                        [1, Highcharts.Color('#FFF').setOpacity(1).get('rgba')],
                    ]
                },
                fillColor : {
                    linearGradient : {
                        x1: 1,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops : [
                        [0, Highcharts.Color('#ffc246').setOpacity(0.7).get('rgba')],
                        [1, Highcharts.Color('#FFF').setOpacity(0).get('rgba')],
                    ]
                }
        }]
    });
    Highcharts.chart('SlideSix_chart', {
        chart: {
            type: 'areaspline',
            spacingTop: 0,
            spacingRight: 0,
            spacingBottom: 0,
            spacingLeft: 0,
            plotBorderWidth: 0
        },
        title: {
            text: null,
            enabled : false
        },
        tooltip: {
            shared: true,
            valueSuffix: ' units'
        },
        credits: {
            enabled: false
        },
        xAxis: {
        categories: [''],
        lineWidth : 0,
        title :{
            text : null
        },
        labels: {
            enabled: false
        }
        },
        yAxis: {
        title :{
            text : null
        },
        visible: false,
        labels: {
            enabled: false
        }
        },
        plotOptions: {
            areaspline: {
                fillOpacity: 0.2
            }
        },
        series: [{
            marker: {
            enabled: false
            },
            lineColor:'#5470de',
            showInLegend: false, 
            data: [2,1 ,4, 3, 5, 4, 10, 6,8,12,5],
            color: {
                    linearGradient : {
                        x1: 1,
                        y1: 0,
                        x2: 0,
                        y2: 0
                    },
                    stops : [
                        [0, Highcharts.Color('#5470de').setOpacity(1).get('rgba')],
                        [1, Highcharts.Color('#FFF').setOpacity(1).get('rgba')],
                    ]
                },
                fillColor : {
                    linearGradient : {
                        x1: 1,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops : [
                        [0, Highcharts.Color('#5470de').setOpacity(0.7).get('rgba')],
                        [1, Highcharts.Color('#FFF').setOpacity(0).get('rgba')],
                    ]
                }
        }]
    });
    Highcharts.chart('SlideSeven_chart', {
        chart: {
            type: 'areaspline',
            spacingTop: 0,
            spacingRight: 0,
            spacingBottom: 0,
            spacingLeft: 0,
            plotBorderWidth: 0
        },
        title: {
            text: null,
            enabled : false
        },
        tooltip: {
            shared: true,
            valueSuffix: ' units'
        },
        credits: {
            enabled: false
        },
        xAxis: {
        categories: [''],
        lineWidth : 0,
        title :{
            text : null
        },
        labels: {
            enabled: false
        }
        },
        yAxis: {
        title :{
            text : null
        },
        visible: false,
        labels: {
            enabled: false
        }
        },
        plotOptions: {
            areaspline: {
                fillOpacity: 0.2
            }
        },
        series: [{
            marker: {
            enabled: false
            },
            lineColor:'#07beaa',
            showInLegend: false, 
            data: [2,1 ,4, 3, 5, 4, 10, 6,8,12,5],
            color: {
                    linearGradient : {
                        x1: 1,
                        y1: 0,
                        x2: 0,
                        y2: 0
                    },
                    stops : [
                        [0, Highcharts.Color('#07beaa').setOpacity(1).get('rgba')],
                        [1, Highcharts.Color('#FFF').setOpacity(1).get('rgba')],
                    ]
                },
                fillColor : {
                    linearGradient : {
                        x1: 1,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops : [
                        [0, Highcharts.Color('#07beaa').setOpacity(0.7).get('rgba')],
                        [1, Highcharts.Color('#FFF').setOpacity(0).get('rgba')],
                    ]
                }
        }]
    });
    Highcharts.chart('SlideEight_chart', {
        chart: {
            type: 'areaspline',
            spacingTop: 0,
            spacingRight: 0,
            spacingBottom: 0,
            spacingLeft: 0,
            plotBorderWidth: 0
        },
        title: {
            text: null,
            enabled : false
        },
        tooltip: {
            shared: true,
            valueSuffix: ' units'
        },
        credits: {
            enabled: false
        },
        xAxis: {
        categories: [''],
        lineWidth : 0,
        title :{
            text : null
        },
        labels: {
            enabled: false
        }
        },
        yAxis: {
        title :{
            text : null
        },
        visible: false,
        labels: {
            enabled: false
        }
        },
        plotOptions: {
            areaspline: {
                fillOpacity: 0.2
            }
        },
        series: [{
            marker: {
            enabled: false
            },
            lineColor:'#1786c4',
            showInLegend: false, 
            data: [2,1 ,4, 3, 5, 4, 10, 6,8,12,5],
            color: {
                    linearGradient : {
                        x1: 1,
                        y1: 0,
                        x2: 0,
                        y2: 0
                    },
                    stops : [
                        [0, Highcharts.Color('#1786c4').setOpacity(1).get('rgba')],
                        [1, Highcharts.Color('#FFF').setOpacity(1).get('rgba')],
                    ]
                },
                fillColor : {
                    linearGradient : {
                        x1: 1,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops : [
                        [0, Highcharts.Color('#1786c4').setOpacity(0.7).get('rgba')],
                        [1, Highcharts.Color('#FFF').setOpacity(0).get('rgba')],
                    ]
                }
        }]
    });
}