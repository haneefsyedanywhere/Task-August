import newsfeed from './newfeed';
export default function(container){
    newsfeed.forEach((news)=>{
        let template = 
        `<div class="newsfeed__news">
            <time>${news.time}</time>
            <h4>${news.headline}</h4>
            <p>${news.content}</p>
            <div class="Ltriangle"></div>
        </div>`;
        container.innerHTML+= template;
    });
}