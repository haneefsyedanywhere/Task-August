import activities from './latestActivities';

export default function(container){
    activities.forEach((activity)=>{
        let template = `
        <tr>
            <td>${activity.date}</td>
            <td>${activity.detail}</td>
            <td>${activity.activities}</td>
        </tr>
    `;
    container.innerHTML+= template;
    });
}