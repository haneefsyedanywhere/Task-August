export default function(){

    let areaSplineDB = [
        {
            svg : "",
            
        }
    ]






}