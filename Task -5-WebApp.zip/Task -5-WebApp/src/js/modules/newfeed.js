export default [
    {
        time : "Today 11:36",
        headline : "Beyond Bad Trades: Cybersecurity Risks to Cryptocurrency Exchange Users",
        content : "Cryptocurrency-mining malware is not the only type of cryptocurrency-related threat — cybercriminals have resorted"
    },
    {
        time : "Yesterday",
        headline : "Ripple News Today: Ripple is planning to upgrade the technology of the cryptocurrency",
        content : "Cryptocurrency-mining malware is not the only type of cryptocurrency-related threat — cybercriminals have resorted"
    },
    {
        time : "Today 11:36",
        headline : "Beyond Bad Trades: Cybersecurity Risks to Cryptocurrency Exchange Users",
        content : "Cryptocurrency-mining malware is not the only type of cryptocurrency-related threat — cybercriminals have resorted"
    },
    {
        time : "Yesterday",
        headline : "Ripple News Today: Ripple is planning to upgrade the technology of the cryptocurrency",
        content : "Cryptocurrency-mining malware is not the only type of cryptocurrency-related threat — cybercriminals have resorted"
    }
]