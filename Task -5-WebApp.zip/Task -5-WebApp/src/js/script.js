  import {documentReady} from './actions';
  import generateTemplate from './modules/marketCapTemplate';
  import {toggleArrow,addListener,debounceFunction,chartGenerator,throttleFunction} from './modules/helperFunctions';
  import newGenerator from './modules/newTemplate';
  import activitiesGenerator from './modules/activitiesTableGenerator';
  import slider,{controlSlidesUsingArrow} from './modules/slider';
  function callback(){
    const container=document.querySelector(".thumbnail-container");
    var containerWidth=container.offsetWidth;
    var totalItemWIdth = slider(containerWidth);
    chartGenerator();

    const toggleNav = document.querySelector('#toggleNav');

    toggleNav.onclick = function(){
      document.querySelector('#navigators').classList.toggle('hide');
      document.querySelector('#sections').classList.toggle('col_12'); 
      document.querySelector('.header__left').classList.toggle('hide');
      document.querySelector('.header__right').classList.toggle('col_12'); 
      document.querySelector(".thumbnail-container").style.width="100%";
      containerWidth=container.offsetWidth;
      totalItemWIdth = slider(containerWidth);
      chartGenerator();
    }

    const nextButton = document.querySelector('.nextButton');
    const prevButton = document.querySelector('.prevButton');
    
    nextButton.addEventListener('click',function(){
      throttleFunction(controlSlidesUsingArrow("next",totalItemWIdth,containerWidth),500);
    });
    prevButton.addEventListener('click',function(){
      throttleFunction(controlSlidesUsingArrow("prev",totalItemWIdth,containerWidth),500);
    });


    const marketCapContent =  document.querySelector('#marketCap__content');
    generateTemplate(marketCapContent)
  
    const newsContainer = document.querySelector('#newsfeed__container');
    newGenerator(newsContainer);

    const activitiesContainer = document.querySelector('.all tbody');
      activitiesGenerator(activitiesContainer);

    const sections = document.querySelector('#sections').children;
    const activities = document.querySelector('.latestActivities__body').children;


    window.viewSection = function(index){
      const navigator = document.querySelectorAll('#navigators li');
      console.log(navigator);
      const navItems = document.querySelector('.nav__items').children;
      for(let i=0 ; i<sections.length ; i++){
        if(!(sections[i].classList.contains('hide'))){
          sections[i].classList.add('hide');
          navigator[i].classList.remove('active');
        }
      }      
      sections[index].classList.remove('hide');

      navigator[index].classList.add('active');
    }   
          

  window.viewActivitiesSections = function(index){
    const navigator = document.querySelector('.latestActivities__head nav ul').children;
    for(let i=0 ; i<activities.length ; i++){
      if(!(activities[i].classList.contains('hide'))){
        activities[i].classList.add('hide');
        navigator[i].classList.remove('active');
      }

    }
    activities[index].classList.remove('hide');
    navigator[index].classList.add('active');
  }          



  const transactions = document.querySelector('#transactions h4');
  const wallet = document.querySelector('#wallet h4');
  const rewards = document.querySelector('#rewards h4');
  const utilityPlan = document.querySelector('#utilityPlan h4');
  addListener(transactions,"transactions");
  toggleArrow(wallet,"wallet");
  toggleArrow(rewards,"rewards");
  toggleArrow(utilityPlan,"utilityPlan");

  window.onresize = function(){
    debounceFunction(chartGenerator,500);
    document.querySelector(".thumbnail-container").style.width="100%";
    containerWidth=container.offsetWidth;
    totalItemWIdth = slider(containerWidth);
  }



}
  
  documentReady(callback);