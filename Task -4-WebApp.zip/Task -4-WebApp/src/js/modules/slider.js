
const margin = 15;
var items = 4;
var jumpSlideWidth;
var jumpSlideWidthOne = 0;
var jumpSlideWidthTwo = 0;

export default function generateSlider(sliderContainer){
    const sliderContainer_Width = sliderContainer.offsetWidth;
    const sliderItems = sliderContainer.children;
    var totalItemsWidth = 0;
    for(let i = 0;i<sliderItems.length;i++){
        sliderItems[i].style.width = (sliderContainer_Width/items)-margin + "px";
        sliderItems[i].style.margin=(margin/2)+ "px";
        totalItemsWidth+= sliderContainer_Width/items;
    }
    return totalItemsWidth;
}

export let sliderControl = function(ele, totalItemsWidth ,sliderContainer_Width,sliderContainer){

    if(sliderContainer.id==="weeklyQuests"){
        jumpSlideWidth = jumpSlideWidthOne;
    }else{
        jumpSlideWidth = jumpSlideWidthTwo;
    }

    if(ele===1 && (jumpSlideWidth<(totalItemsWidth-sliderContainer_Width))){
        jumpSlideWidth=jumpSlideWidth+sliderContainer_Width;

      }
      else if(ele=== 0 && (jumpSlideWidth>0)){
        jumpSlideWidth=jumpSlideWidth-sliderContainer_Width;
      }
      sliderContainer.style.marginLeft=-jumpSlideWidth + "px";  

      if(sliderContainer.id==="weeklyQuests"){
          jumpSlideWidthOne = jumpSlideWidth;
      }else{
          jumpSlideWidthTwo = jumpSlideWidth;
      }

      const sliderControllers = sliderContainer.previousElementSibling.querySelectorAll('span');
      const prev_icon = sliderControllers[0];
      const next_icon = sliderControllers[1];
      if(jumpSlideWidth>0){
        prev_icon.classList.remove('disabled');
      }
      if((jumpSlideWidth+sliderContainer_Width)<=totalItemsWidth){
        next_icon.classList.remove('disabled');
      }
      if(jumpSlideWidth==0){
        prev_icon.classList.add('disabled');
      }
      if((jumpSlideWidth+sliderContainer_Width)>=totalItemsWidth){
        next_icon.classList.add('disabled');
      }
  }