export let toggleHide = function(element){
    element.classList.toggle('hide');
  }


