import {emailAttachment} from './emailAttachment';

 export let toogleOverFlow = function(toggleMailBoxView){
  const mailBox = document.querySelector('.mailbox');
  mailBox.classList.toggle('showOverFlow');
  if(mailBox.classList.contains('showOverFlow')){
    toggleMailBoxView.querySelector('span').innerHTML="Show Less";
  }else{
    mailBox.scrollTo(0,0);
    toggleMailBoxView.querySelector('span').innerHTML="More";
  }
}

let eventHandler;
export let renderInbox = function (arr,container,arrName){
  container.innerHTML="";
  arr.forEach((mailInfo,index)=>{ 
    if(arrName === "mailInfo"){
      eventHandler = `onclick="viewMail(${index})"`;
    }else{
      eventHandler = `onclick="viewTrashMail(${index})"`;        
    }
    let mail = `<div class="mail" ${eventHandler}>
                  <span id="newMailIndicator" ${mailInfo.viewed ? 'class="hide"':''}></span>
                  <div class="mail__info_left">
                      <h4>${mailInfo.subject}</h4>
                      <p>${mailInfo.senderName}</p>    
                  </div>
                  <div class="mail__info_right">
                      <p>${mailInfo.timeStamp}</p>
                      <svg class="attachSvg ${mailInfo.attachment ? '' : 'hide'}" x="0px" y="0px" viewBox="0 0 511.991 511.991" style="enable-background:new 0 0 511.991 511.991;" xml:space="preserve" width="13px" height="11px">
                        <g>
                          <path style="fill:#8e8e93;" d="M486.241,65.831L467.49,47.079c-34.333-34.333-89.997-34.333-124.33-0.001c0,0,0,0-0.001,0.001  L103.543,286.695c-24.277,24.277-24.277,63.638,0,87.915l12.501,12.501c24.728,23.163,63.187,23.163,87.915,0l176.917-176.917  c4.237-4.093,4.354-10.845,0.262-15.083c-4.093-4.237-10.845-4.354-15.083-0.262c-0.089,0.086-0.176,0.173-0.262,0.262  L188.876,372.028c-16.248,15.203-41.501,15.203-57.749,0l-12.501-12.501c-15.947-15.945-15.949-41.798-0.004-57.745  c0.001-0.001,0.003-0.003,0.004-0.004L358.241,62.161c26.366-25.112,67.8-25.112,94.165,0l18.752,18.752  c25.993,26.007,25.993,68.158,0,94.165l-267.2,267.2c-36.063,36.05-94.518,36.05-130.581,0l-25.003-24.981  c-36.05-36.063-36.05-94.518,0-130.581L252.876,82.215c4.237-4.093,4.355-10.845,0.262-15.083  c-4.093-4.237-10.845-4.355-15.083-0.262c-0.089,0.086-0.176,0.173-0.262,0.262L33.292,271.612  C-11.097,316-11.097,387.968,33.291,432.357c0,0.001,0.001,0.001,0.001,0.001l25.003,25.003  c44.388,44.389,116.356,44.39,160.745,0.002c0-0.001,0.001-0.001,0.001-0.002l267.2-267.2  C520.574,155.829,520.575,100.164,486.241,65.831C486.242,65.831,486.242,65.831,486.241,65.831L486.241,65.831z" data-original="#CFD8DC" class=""/><path d="M138.658,490.663c-30.164,0.066-59.104-11.923-80.384-33.301L33.292,432.38c-44.389-44.388-44.39-116.356-0.001-160.745  c0,0,0.001-0.001,0.001-0.001L237.794,67.132c4.093-4.237,10.845-4.355,15.083-0.262c4.237,4.093,4.355,10.845,0.262,15.083  c-0.086,0.089-0.173,0.176-0.262,0.262L48.375,286.695c-36.05,36.063-36.05,94.518,0,130.581l25.003,25.003  c36.063,36.05,94.518,36.05,130.581,0l267.2-267.2c25.993-26.007,25.993-68.158,0-94.165l-18.752-18.752  c-26.366-25.112-67.8-25.112-94.165,0L118.625,301.777c-15.947,15.945-15.949,41.798-0.004,57.745  c0.001,0.001,0.003,0.003,0.004,0.004l12.501,12.501c16.248,15.203,41.501,15.203,57.749,0l176.917-176.917  c4.093-4.237,10.845-4.355,15.083-0.262c4.237,4.093,4.354,10.845,0.262,15.083c-0.086,0.089-0.173,0.176-0.262,0.262  L203.959,387.111c-24.728,23.163-63.187,23.163-87.915,0l-12.501-12.501c-24.277-24.277-24.277-63.638,0-87.915L343.159,47.079  c34.333-34.333,89.997-34.333,124.33-0.001c0,0,0,0,0.001,0.001l18.752,18.752c34.333,34.333,34.333,89.997,0.001,124.33  c0,0,0,0-0.001,0.001l-267.2,267.2C197.762,478.74,168.822,490.729,138.658,490.663z" data-original="#000000" class="hovered-path active-path" style="fill:#8E8E93" data-old_color="#000000"/>
                        </g> 
                      </svg>
                  </div>
                </div>`;
  container.innerHTML+=mail;
  })  
}

export let addMailContent =  function(arr,mailId){
  document.querySelector('#email__subject').innerHTML = arr[mailId].subject;
  document.querySelector('#email__sender__name').innerHTML = arr[mailId].senderName;
  document.querySelector('#email__sender__mailId').innerHTML = arr[mailId].senderMailId;
  document.querySelector('.email_sender__timestamp').innerHTML = arr[mailId].timeStamp;
  document.querySelector('.email__content').innerHTML = arr[mailId].content;
  if(arr[mailId].attachment){
    document.querySelector('#inbox .email__attachment').innerHTML = emailAttachment;
    document.querySelector('#inbox .email__attachment').classList.remove('hide');  
  }else{
    document.querySelector('#inbox .email__attachment').classList.add('hide');  
  }
}
export let addTrashMailContent = function(arr,mailId){
  document.querySelector('#trash #email__subject').innerHTML = arr[mailId].subject;
  document.querySelector('#trash #email__sender__name').innerHTML = arr[mailId].senderName;
  document.querySelector('#trash #email__sender__mailId').innerHTML = arr[mailId].senderMailId;
  document.querySelector('#trash .email_sender__timestamp').innerHTML = arr[mailId].timeStamp;
  document.querySelector('#trash .email__content').innerHTML = arr[mailId].content;
  if(arr[mailId].attachment){
    document.querySelector('#trash .email__attachment').innerHTML = emailAttachment;
    document.querySelector('#trash .email__attachment').classList.remove('hide');  
  }else{
    document.querySelector('#trash .email__attachment').classList.add('hide');  
  }
}