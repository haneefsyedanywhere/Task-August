export default [
    {
      subject:"Design Language",
      senderName : "Salman Shah",
      senderMailId : "salmanShah@gmail.com",
      timeStamp : "08:00 PM",
      content : "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, perspiciatis dolorem nulla assumenda minima officia fugiat accusantium. Dolorum, pariatur praesentium corporis nesciunt veritatis id ea eveniet voluptates aperiam quod sit!",
      attachment : false,
      viewed : false
    },
    {
      subject:"Nextmail New Look",
      senderName : "Christian Bale",
      senderMailId : "christian.bale@gmail.com",
      timeStamp : "11:00 PM",
      content :"Hello Ben Affleck,<br><br>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.<br><br>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.<br><br>CheersDesignAvenger" ,
      attachment : true,
      attachmentName : "Subject.pdf",
      viewed : false
    },
    {
      subject:"Interview with Shopify",
      senderName : "Aisha Dialo",
      senderMailId : "aishaDialo@gmail.com",
      timeStamp : "12:05 PM",
      content : "  Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, perspiciatis dolorem nulla assumenda minima officia fugiat accusantium. Dolorum, pariatur praesentium corporis nesciunt veritatis id ea eveniet voluptates aperiam quod sit!",
      attachment : false,
      viewed : false
    },
    {
      subject:"Narcos Season 2",
      senderName : "Netflix",
      senderMailId : "netflix@gmail.com",
      timeStamp : "07:35 PM",
      content : "  Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, perspiciatis dolorem nulla assumenda minima officia fugiat accusantium. Dolorum, pariatur praesentium corporis nesciunt veritatis id ea eveniet voluptates aperiam quod sit!",
      attachment : false,
      viewed : false
    },
    {
      subject:"Top Stories of the Day",
      senderName : "TechCrunch",
      senderMailId : "techCrunch@gmail.com",
      content : "  Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, perspiciatis dolorem nulla assumenda minima officia fugiat accusantium. Dolorum, pariatur praesentium corporis nesciunt veritatis id ea eveniet voluptates aperiam quod sit!",
      timeStamp : "Yesterday",
      attachment : false,
      viewed : false
    },
    {
      subject:"Updates from Kevin",
      senderName : "Goodreads",
      senderMailId : "kevin@gmail.com",
      timeStamp : "Yesterday",
      content : "  Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, perspiciatis dolorem nulla assumenda minima officia fugiat accusantium. Dolorum, pariatur praesentium corporis nesciunt veritatis id ea eveniet voluptates aperiam quod sit!",
      attachment : false,
      viewed : false
    },
    {
      subject:"Startup",
      senderName : "2016",
      senderMailId : "startup@gmail.com",
      timeStamp : "09 Oct 16",
      content : "  Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, perspiciatis dolorem nulla assumenda minima officia fugiat accusantium. Dolorum, pariatur praesentium corporis nesciunt veritatis id ea eveniet voluptates aperiam quod sit!",
      attachment : false,
      viewed : false
    },
    {
      subject:"Random Content",
      senderName : "Random Person",
      senderMailId : "random@gmail.com",
      timeStamp : "09 Jul 16",
      content : "  Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, perspiciatis dolorem nulla assumenda minima officia fugiat accusantium. Dolorum, pariatur praesentium corporis nesciunt veritatis id ea eveniet voluptates aperiam quod sit!",
      attachment : false,
      viewed : false
    }
  ];