  import {documentReady} from './actions';
  documentReady(callback);

  function callback(){
     
  import mailInfo from './modules/mailInfo';
  import {renderInbox,addMailContent,addTrashMailContent,toogleOverFlow} from './modules/helper';
  
  const mailBoxWrapper = document.querySelector('#mailboxWrapper');
  const mailBoxNavigator = document.querySelectorAll('.mailbox li');
  const mailBoxSections = document.querySelectorAll('#mailboxWrapper section');
  const toggleMailBoxView = document.querySelector('#toggleMailBoxView');

  //mailBox scroll 
  toggleMailBoxView.onclick = ()=>{toogleOverFlow(toggleMailBoxView)};


  // mailBox Navigator
  window.toggleView = function(num){
    for(var i=0;i<mailBoxSections.length;i++){
      if(!(mailBoxSections[i].classList.contains('hide'))){
        mailBoxSections[i].classList.add('hide');
         mailBoxNavigator[i].classList.remove('active');
      }
    }
    labelWrapper.classList.add('hide');
    mailBoxWrapper.classList.remove('hide');
    mailBoxSections[num].classList.remove('hide');
    mailBoxNavigator[num].classList.add('active');
  };

    // label Navigator
  const labelWrapper = document.querySelector('#labelWrapper');
  const labelSections = document.querySelectorAll('#labelWrapper section');
  const labelNavigator = document.querySelectorAll('.labels li');
  window.toggleLabel = function(num){
      for(var i=0;i<labelSections.length;i++){
        if(!(labelSections[i].classList.contains('hide'))){
          labelSections[i].classList.add('hide');
           labelNavigator[i].classList.remove('active');
        }
      }
      labelWrapper.classList.remove('hide');
      mailBoxWrapper.classList.add('hide');
      labelSections[num].classList.remove('hide');
      labelNavigator[num].classList.add('active');
  
    }
  //MAIL
  const emailContainer = document.querySelector('#inbox #email');
  const inbox_container = document.querySelector('#inbox .inbox__container');
  const mail = inbox_container.children;
  const trashContainer = document.querySelector('#trash .inbox__container');
  const trashContainerChildrens = trashContainer.children;
  const trash_emailContainer =  document.querySelector('#trash #email');
  const trashButton = document.querySelector('#trashButton');
  let trashMails = [];
  let activeMail ;


    const dropDown_Option = document.querySelector('.dropdown__options');
    window.viewDropdown = function(){
      dropDown_Option.classList.toggle('hide');
    };
    const dropdown_Option_values = dropDown_Option.children;
    window.selectOption = function(optionNum){
      document.querySelector('.dropdown input').value = dropdown_Option_values[optionNum].innerHTML;
      dropDown_Option.classList.add('hide');      
    };
    const trashdropDown_Option = document.querySelector('#trash .dropdown__options');
    window.viewDropdown = function(){
      trashdropDown_Option.classList.toggle('hide');
    };
    const trashDropdown_Option_values = trashdropDown_Option.children;
    window.selectOption = function(optionNum){
      document.querySelector('#trash .dropdown input').value = trashDropdown_Option_values[optionNum].innerHTML;
      trashdropDown_Option.classList.add('hide');      
    };
    
    window.viewMail = function(mailId){
      emailContainer.classList.remove('hide');
      for(var i=0;i<mail.length;i++){
        if(mail[i].classList.contains('mail_active')){
          mail[i].classList.remove('mail_active');
          }
      }
      mailInfo[mailId].viewed=true;
      addMailContent(mailInfo,mailId);
      mail[mailId].classList.add("mail_active");
      mail[mailId].querySelector('#newMailIndicator').classList.add('hide');
    }
    window.viewTrashMail = function(mailId){
      trash_emailContainer.classList.remove('hide');
      for(var i=0;i<trashContainerChildrens.length;i++){
        if(trashContainerChildrens[i].classList.contains('mail_active')){
          trashContainerChildrens[i].classList.remove('mail_active');
          }
      }
      addTrashMailContent(trashMails,mailId);
      trashContainerChildrens[mailId].classList.add("mail_active");
    }
  
  const confirmationPopUp = document.querySelector('.confirmationPopUp');
  const confirmDelete = confirmationPopUp.children[2];
  const closePopUp  = document.querySelectorAll('.confirmationPopUp__closeBtn');
  
  window.onclick = function(event) {
    if (event.target == trashButton) {
      confirmationPopUp.classList.remove('hide');
    }else{
      confirmationPopUp.classList.add('hide');
    }
    if(!((event.target == document.querySelector('.dropdown input')) || (event.target == document.querySelector('.dropdown svg')))){
      dropDown_Option.classList.add('hide');     
    }
    if(!((event.target == document.querySelector('#trash .dropdown input')) || (event.target == document.querySelector('#trash .dropdown svg')))){
      trashdropDown_Option.classList.add('hide');     
    }

  }
  closePopUp.forEach((ele)=>{
    ele.onclick = function(){
      confirmationPopUp.classList.add('hide');
    }
  })
  
  confirmDelete.addEventListener('click',()=>{
    confirmationPopUp.classList.add('hide');
    for(var i=0;i<mail.length;i++){
      if(mail[i].classList.contains('mail_active')){
        activeMail = i;
        break;
      }
    }
    trashMails.unshift(mailInfo[activeMail]);
    mailInfo.splice(activeMail,1);
    inbox_container.innerHTML="";
    renderInbox(mailInfo,inbox_container,"mailInfo");
    renderInbox(trashMails,trashContainer,"trashMails");
    emailContainer.classList.add('hide');
    mailBoxNavigator[0].querySelector('span').innerHTML = `Inbox (${mailInfo.length})`;
    mailBoxNavigator[3].querySelector('span').innerHTML = `Trash (${trashMails.length})`;
  });
  
  window.onload=()=>{
    renderInbox(mailInfo,inbox_container,"mailInfo");
    mailBoxNavigator[0].querySelector('span').innerHTML = `Inbox (${mailInfo.length})`;
    mailBoxNavigator[3].querySelector('span').innerHTML = `Trash (${trashMails.length})`;
  }  

  }
  
 